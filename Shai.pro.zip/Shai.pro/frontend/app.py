# frontend/app.py
# Streamlit UI: отправляет NL-запрос на backend, отображает SQL, таблицу и пояснение.
import streamlit as st
import requests
import pandas as pd
import os
from urllib.parse import urljoin

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

st.set_page_config(page_title="BI-GPT", layout="wide")

st.title("BI-GPT — Natural Language → SQL (MVP)")
st.markdown("Задайте вопрос на естественном языке — агент постарается сгенерировать безопасный SQL и вернуть результат.")

with st.sidebar:
    st.header("Примеры")
    if st.button("Прибыль за последние 2 дня"):
        st.session_state.question = "Покажи прибыль за последние 2 дня"
    if st.button("Средний чек за месяц"):
        st.session_state.question = "Средний чек за текущий месяц по всем магазинам"
    if st.button("Остатки на складах"):
        st.session_state.question = "Покажи остатки по складам, сортируя по убыванию"

question = st.text_area("Вопрос (Natural language)", value=st.session_state.get("question", ""), height=120)
col1, col2 = st.columns([1, 2])

with col1:
    max_rows = st.number_input("Макс строк (frontend лимит)", min_value=10, max_value=10000, value=500, step=10)
    submit = st.button("Отправить вопрос")

with col2:
    st.write("Результат:")

if submit and question.strip():
    payload = {"question": question, "max_rows": int(max_rows)}
    try:
        with st.spinner("Запрашиваю LLM и выполняю SQL..."):
            r = requests.post(urljoin(BACKEND_URL, "/query"), json=payload, timeout=60)
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        st.error(f"Ошибка запроса: {e}")
    else:
        st.subheader("Сгенерированный SQL")
        st.code(data.get("sql", ""), language="sql")
        st.subheader("Объяснение")
        st.write(data.get("explanation", ""))
        rows = data.get("rows", [])
        if rows:
            df = pd.DataFrame(rows)
            st.subheader(f"Результат — {len(df)} строк")
            st.dataframe(df)
            # простая визуализация: если есть числовые колонки, покажем график
            numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
            if numeric_cols:
                col = st.selectbox("График: выбрать числовую колонку", numeric_cols)
                st.line_chart(df[col])
        else:
            st.info("Запрос выполнил, но строк не вернул (проверьте SQL или уменьшите лимит).")

st.markdown("---")
if st.button("Показать allowlist схемы (debug)"):
    try:
        r = requests.get(urljoin(BACKEND_URL, "/schema"), timeout=10)
        r.raise_for_status()
        st.json(r.json())
    except Exception as e:
        st.error(f"Не удалось получить схему: {e}")
