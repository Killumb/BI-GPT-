# BI-GPT (MVP)
Agent: Natural Language → SQL (Llama 4 Scout FP8)

## Требования
- Python 3.10+
- PostgreSQL с данными (локально или удалённо)
- Доступ к Llama 4 Scout (URL в переменной LLM_URL)

## Установка (Windows)
1. Создать виртуальное окружение:
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
