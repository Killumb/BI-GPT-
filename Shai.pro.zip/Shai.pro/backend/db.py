# backend/db.py
# Работа с PostgreSQL (asyncpg). Простой пул, выполнение только SELECT-запросов.
import asyncio
import json
import re
from typing import List, Tuple, Any

import asyncpg
from loguru import logger
from pathlib import Path


class Database:
    def __init__(self, dsn: str):
        self._dsn = dsn
        self._pool: asyncpg.pool.Pool = None
        # business_glossary.json лежит рядом с этим файлом в backend/
        self._glossary_path = Path(__file__).parent / "business_glossary.json"

    async def init(self):
        if not self._dsn:
            raise RuntimeError("DATABASE_DSN не задан")
        self._pool = await asyncpg.create_pool(dsn=self._dsn, min_size=1, max_size=5)
        logger.info("DB connection pool created")

    def load_business_glossary(self) -> dict:
        if not self._glossary_path.exists():
            logger.warning("business_glossary.json не найден, возвращаю пустой словарь")
            return {}
        with open(self._glossary_path, "r", encoding="utf-8") as f:
            return json.load(f)

    async def close(self):
        if self._pool:
            await self._pool.close()
            logger.info("DB pool closed")

    async def fetch_sql(self, sql: str, limit: int = 1000) -> Tuple[List[Tuple[Any, ...]], List[str]]:
        """
        Выполняет SELECT SQL и возвращает rows и names(columns).
        Подрезаем количество строк с помощью LIMIT, если его нет.
        """
        # Простая защита: если в запросе нет слова LIMIT — добавляем; но не для подзапросов в скобках
        safe_sql = self._ensure_limit(sql, limit)
        async with self._pool.acquire() as conn:
            # Сделаем readonly транзакцию
            async with conn.transaction(readonly=True):
                stmt = await conn.prepare(safe_sql)
                records = await stmt.fetch()
                columns = [a.name for a in stmt.get_attributes()]
                rows = [tuple(r) for r in records]
                return rows, columns

    def _ensure_limit(self, sql: str, limit: int) -> str:
        # Простая проверка на вхождение "LIMIT" (без учёта подзапросов)
        if re.search(r"\blimit\b", sql, flags=re.IGNORECASE):
            return sql
        # добавляем LIMIT в конце
        return sql.rstrip("; \n\t") + f" LIMIT {int(limit)};"
