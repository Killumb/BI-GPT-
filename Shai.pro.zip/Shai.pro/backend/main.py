# backend/main.py
# FastAPI backend для BI-GPT: принимает NL, запрашивает LLM, валидирует SQL, выполняет запрос и возвращает результат.
import os
import asyncio
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

from db import Database
from llm import LLMClient
from sql_validator import SQLValidator
from config import settings

app = FastAPI(title="BI-GPT: Natural Language → SQL agent")

# CORS для локальной разработки (Streamlit фронтенд)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501", "http://127.0.0.1:8501"] + settings.CORS_ORIGINS,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


class NLQuery(BaseModel):
    question: str
    max_rows: int = settings.DEFAULT_MAX_ROWS


# глобальные объекты (инициализируем при старте)
db: Database = None
llm: LLMClient = None
validator: SQLValidator = None


@app.on_event("startup")
async def startup_event():
    global db, llm, validator
    db = Database(dsn=settings.DATABASE_DSN)
    await db.init()
    llm = LLMClient(base_url=settings.LLM_URL, api_key=settings.LLM_API_KEY, timeout=settings.LLM_TIMEOUT)
    glossary = db.load_business_glossary()  # словарь берётся из файла business_glossary.json
    validator = SQLValidator(allowed_schema=glossary.get("allowed_tables", {}), max_rows_limit=settings.MAX_ROWS_LIMIT)
    app.state.glossary = glossary


@app.on_event("shutdown")
async def shutdown_event():
    global db
    if db:
        await db.close()


@app.post("/query")
async def handle_query(payload: NLQuery) -> Dict[str, Any]:
    question = payload.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Пустой вопрос")

    # 1) Формируем подсказку и запрашиваем LLM
    prompt_context = {
        "question": question,
        "glossary": app.state.glossary,
        "max_rows": min(payload.max_rows, settings.DEFAULT_MAX_ROWS),
    }

    try:
        llm_response = await llm.generate_sql_and_explanation(prompt_context)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка LLM: {str(e)}")

    sql = llm_response.get("sql")
    explanation = llm_response.get("explanation", "")

    if not sql:
        raise HTTPException(status_code=500, detail="LLM не вернул SQL")

    # 2) Валидация SQL
    try:
        validator.validate(sql)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"SQL validation failed: {e}")

    # 3) Выполнение (read-only)
    try:
        rows, columns = await db.fetch_sql(sql, limit=payload.max_rows)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка выполнения SQL: {e}")

    # 4) Возвращаем структуру: sql, explanation, columns, rows (list of dicts)
    results = [dict(zip(columns, r)) for r in rows]

    return {
        "sql": sql,
        "explanation": explanation,
        "rows": results,
        "row_count": len(results),
        "columns": columns,
    }


@app.get("/schema")
async def get_schema():
    """Возвращает разрешённую схему (для фронтенда / отладки)."""
    glossary = app.state.glossary
    return {"glossary": glossary}
