# backend/sql_validator.py
# Валидация и проверка безопасности SQL: запрет опасных ключевых слов, разрешённые таблицы/колонки.
import re
import sqlparse
from typing import Dict, List


class SQLValidationError(Exception):
    pass


class SQLValidator:
    def __init__(self, allowed_schema: Dict[str, List[str]], max_rows_limit: int = 10000):
        """
        allowed_schema: { "table_name": ["col1", "col2", ...], ... }
        """
        self.allowed_schema = {k.lower(): [c.lower() for c in v] for k, v in (allowed_schema or {}).items()}
        self.forbidden_patterns = [
            r"\binsert\b", r"\bupdate\b", r"\bdelete\b", r"\bdrop\b", r"\balter\b",
            r"\bcreate\b", r"\bgrant\b", r"\brevoke\b", r"\btruncate\b", r";", r"\bexec\b", r"\bcall\b"
        ]
        self.max_rows_limit = max_rows_limit

    def validate(self, sql: str):
        if not sql or not isinstance(sql, str):
            raise SQLValidationError("SQL пуст или некорректного типа")

        lowered = sql.lower()
        # 1) Запрет ключевых слов
        for patt in self.forbidden_patterns:
            if re.search(patt, lowered):
                raise SQLValidationError(f"Обнаружен запрещённый паттерн в SQL: {patt}")

        # 2) Разбираем SQL и убеждаемся, что это SELECT
        parsed = sqlparse.parse(sql)
        if len(parsed) == 0:
            raise SQLValidationError("Невозможно распарсить SQL")
        stmt = parsed[0]
        first_token = stmt.token_first(skip_cm=True)
        if first_token is None or first_token.normalized.upper() != "SELECT":
            raise SQLValidationError("Разрешены только SELECT-запросы")

        # 3) Проверка, что все используемые таблицы входят в allowed_schema
        used_tables = self._extract_table_names(sql)
        if self.allowed_schema:  # если схема задана — применяем жёсткую проверку
            for t in used_tables:
                if t.lower() not in self.allowed_schema:
                    raise SQLValidationError(f"Таблица '{t}' не в allowlist")

        # 4) Ограничение количества возвращаемых строк (не строгая проверка)
        # проверяем если есть OFFSET без LIMIT или отсутствует LIMIT — поведение оставляем на стороне выполнения
        # (в DB.fetch_sql добавляется LIMIT по умолчанию)

    def _extract_table_names(self, sql: str) -> List[str]:
        """
        Простейший извлекатель имён таблиц из частей FROM и JOIN.
        Не идеален, но для большинства простых SELECT-хвостов работает.
        """
        sqll = sql
        # Найдём конструкции FROM ... (WHERE|JOIN|GROUP|ORDER|LIMIT|$)
        tables = []
        for m in re.finditer(r"\bfrom\s+([^\s,;]+)", sqll, flags=re.IGNORECASE):
            tables.append(self._clean_ident(m.group(1)))
        for m in re.finditer(r"\bjoin\s+([^\s,;]+)", sqll, flags=re.IGNORECASE):
            tables.append(self._clean_ident(m.group(1)))
        # Удаляем alias: "schema.table as t" -> "schema.table"
        cleaned = []
        for t in tables:
            # удаляем скобки и alias
            t = t.strip()
            t = re.sub(r"\bAS\b.*", "", t, flags=re.IGNORECASE)
            t = re.split(r"\s+", t)[0]
            t = t.strip('"').strip("'")
            # если есть schema.table -> берем только table часть
            if "." in t:
                t = t.split(".")[-1]
            cleaned.append(t)
        # unique
        return list(dict.fromkeys([c for c in cleaned if c]))

    def _clean_ident(self, s: str) -> str:
        return s.strip().strip(",")
