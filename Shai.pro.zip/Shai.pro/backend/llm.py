# backend/llm.py
# Унифицированный клиент для Llama 4 Scout (или любого open-source LLM с HTTP API).
# Ожидается, что LLM принимает JSON и возвращает текст, содержащий JSON: {"sql": "...", "explanation": "..."}
import os
import json
import re
from typing import Dict, Any
import httpx

from loguru import logger


class LLMClient:
    def __init__(self, base_url: str, api_key: str = None, timeout: int = 30):
        if not base_url:
            raise RuntimeError("LLM URL не указан")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client = httpx.AsyncClient(timeout=self.timeout)

    async def generate_sql_and_explanation(self, context: Dict[str, Any]) -> Dict[str, str]:
        """
        context: {
            "question": "...",
            "glossary": {...},
            "max_rows": 100
        }
        Мы формируем жёстко-структурированный prompt, требуем вывод JSON.
        """
        prompt = self._build_prompt(context)
        payload = {
            "input": prompt,
            # структура полезна для разных LLM-интерфейсов; при необходимости откорректируй под конкретный endpoint
            "parameters": {"temperature": 0.0, "max_new_tokens": 512}
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        logger.debug("Sending request to LLM")
        # POST в base_url + '/generate' или просто base_url — зависит от endpoint; сделаем попытку /generate
        targets = [self.base_url + "/generate", self.base_url]
        last_exc = None
        for url in targets:
            try:
                r = await self._client.post(url, json=payload, headers=headers)
                text = r.text
                if r.status_code >= 400:
                    last_exc = Exception(f"LLM returned {r.status_code}: {text[:500]}")
                    continue
                # Попробуем распарсить JSON внутри ответа
                parsed = self._extract_json(text)
                if parsed:
                    return parsed
                # Если не получилось — пробуем взять весь текст как SQL (fallback)
                logger.debug("LLM response didn't contain JSON, trying to interpret raw text")
                return self._interpret_raw_text(text)
            except Exception as e:
                logger.error(f"LLM request to {url} failed: {e}")
                last_exc = e
        raise last_exc or RuntimeError("LLM запрос провалился")

    def _build_prompt(self, context: Dict[str, Any]) -> str:
        q = context["question"]
        glossary = context.get("glossary", {})
        max_rows = context.get("max_rows", 100)
        # Промпт — строгая инструкция: выводить только JSON со структурой {"sql": "...", "explanation": "..."}
        prompt = f"""
You are a strict SQL-generation assistant for a corporate BI database. 
User question: \"{q}\"

Rules:
1) Generate a single READ-ONLY SQL SELECT query that answers the user's question.
2) Use the business glossary and allowed tables/columns if provided.
3) NEVER output any PII values or raw credentials.
4) Do NOT use multiple statements, DDL, or data-modifying statements.
5) If the question requires unavailable columns/tables, explain that in "explanation" and produce the closest possible query.
6) Limit rows to {max_rows} if applicable (you may use LIMIT).
7) Output EXACTLY a JSON object (no extra text) with two fields:
   {{
     "sql": "<your SQL string>",
     "explanation": "<short human-readable explanation in Russian or English>"
   }}
Do not wrap JSON in markdown. Only output JSON.
Glossary (may be empty): {json.dumps(glossary)}
"""
        return prompt.strip()

    def _extract_json(self, text: str) -> Dict[str, str]:
        # Находим первый JSON-объект в тексте
        # 1) Попробуем простой parse
        text = text.strip()
        # Если тело уже JSON
        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                return self._normalize(obj)
        except Exception:
            pass
        # 2) Найти {...} блок
        m = re.search(r"(\{(?:.|\n)*\})", text)
        if m:
            candidate = m.group(1)
            try:
                obj = json.loads(candidate)
                return self._normalize(obj)
            except Exception:
                pass
        return None

    def _interpret_raw_text(self, text: str) -> Dict[str, str]:
        """
        Фоллбэк: если модель вернула SQL в чистом виде, пытаемся отделить SQL и объяснение.
        """
        # Попытаемся найти первый SELECT ... ;
        m = re.search(r"(SELECT[\s\S]*?;)", text, flags=re.IGNORECASE)
        if m:
            sql = m.group(1).strip()
            rest = text.replace(sql, "").strip()
            return {"sql": sql, "explanation": rest[:1000]}
        # иначе — возвращаем весь текст как explanation
        return {"sql": "", "explanation": text[:2000]}

    def _normalize(self, obj: Dict[str, Any]) -> Dict[str, str]:
        sql = obj.get("sql") or obj.get("query") or ""
        explanation = obj.get("explanation") or obj.get("explain") or ""
        return {"sql": sql.strip(), "explanation": explanation.strip()}
