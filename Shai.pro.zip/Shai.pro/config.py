# config.py
# Простая конфигурация: подтягиваем из окружения, даём разумные дефолты.
import os
from typing import List
from pydantic import BaseSettings, AnyUrl


class Settings(BaseSettings):
    LLM_URL: str = os.getenv("LLM_URL", "")
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    DATABASE_DSN: str = os.getenv("DATABASE_DSN", "postgresql://postgres:password@localhost:5432/bi_db")
    DEFAULT_MAX_ROWS: int = int(os.getenv("DEFAULT_MAX_ROWS", "500"))
    MAX_ROWS_LIMIT: int = int(os.getenv("MAX_ROWS_LIMIT", "10000"))
    LLM_TIMEOUT: int = int(os.getenv("LLM_TIMEOUT", "30"))
    CORS_ORIGINS: List[str] = []
    # для фронтенда/бэкенда
    BACKEND_HOST: str = os.getenv("BACKEND_HOST", "0.0.0.0")
    BACKEND_PORT: int = int(os.getenv("BACKEND_PORT", "8000"))

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
# экспорты упрощения доступа
LLM_URL = settings.LLM_URL
LLM_API_KEY = settings.LLM_API_KEY
DATABASE_DSN = settings.DATABASE_DSN
